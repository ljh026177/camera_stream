import serial
from camera_interface import get_img, crop_img
from inference_api_2 import inference_request
import cv2
import os

ser = serial.Serial("COM4", 9600)
api_url = "https://suite-endpoint-api-apne2.superb-ai.com/endpoints/99a4137b-11b4-4daf-841b-643ba67fd52b/inference"

# 저장할 폴더 이름 지정
save_folder = "thrid_model_2"
os.makedirs(save_folder, exist_ok=True)  # 폴더가 없으면 생성

image_counter = 0  # 이미지 파일 이름을 위한 카운터

while True:
    data = ser.read()
    print(data)
    if data == b"0":
        img = get_img()

        crop_info = {"x": 200, "y": 100, "width": 300, "height": 300}
        if crop_info is not None:
            img = crop_img(img, crop_info)

        if img is None or img.size == 0:
            print("Invalid image for displaying")
            continue

        result_img, box_count = inference_request(img, api_url)
        if result_img is not None:
            # 박스 개수가 9개면 "정상", 그 외는 "비정상" 출력
            if box_count == 9:
                print("정상")
            else:
                print("비정상")

            while True:
                cv2.imshow("Image", result_img)
                key = cv2.waitKey(1)

                if key == 27:  # ESC 키를 누르면 종료
                    cv2.destroyAllWindows()
                    exit(0)

                # elif key == ord('w') or key == ord('W'):  # 'w' 키를 누르면 이미지 저장
                #     image_counter += 1
                #     image_path = os.path.join(save_folder, f"captured_image_{image_counter}.jpg")
                #     cv2.imwrite(image_path, result_img)
                #     print(f"Image saved at: {image_path}")

                elif key == ord('q'):  # 'q' 키를 누르면 현재 창 닫기
                    cv2.destroyAllWindows()
                    break

            ser.write(b"1")
    else:
        pass
