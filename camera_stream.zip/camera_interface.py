import cv2

def get_img():
    """Get Image From USB Camera

    Returns:
        numpy.array: Image numpy array
    """
    cam = cv2.VideoCapture(1,cv2.CAP_DSHOW)

    if not cam.isOpened():
        print("Camera Error")
        exit(-1)

    ret, img = cam.read()
    if not ret or img is None:
        print("Failed to capture image")
        cam.release()
        exit(-1)

    cam.release()
    return img

def crop_img(img, size_dict):
    x = size_dict["x"]
    y = size_dict["y"]
    w = size_dict["width"]
    h = size_dict["height"]

    h_img, w_img, _ = img.shape
    if x + w > w_img or y + h > h_img:
        print("Crop size exceeds image dimensions")
        exit(-1)

    img = img[y: y + h, x: x + w]
    return img
