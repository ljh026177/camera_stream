import serial
from camera_interface1 import get_img, crop_img, release_camera
from inference_api_2 import inference_request
import cv2

# 시리얼 포트 설정
ser = serial.Serial("COM4", 9600)
api_url = "https://suite-endpoint-api-apne2.superb-ai.com/endpoints/99a4137b-11b4-4daf-841b-643ba67fd52b/inference"

result_img = None
box_count = 0

try:
    while True:
        # 실시간 카메라 피드 표시
        img = get_img()
        if img is None:
            continue

        cv2.imshow("Live Feed", img)
        key = cv2.waitKey(1)

        # 시리얼 신호 수신 대기
        if ser.in_waiting:
            data = ser.read()
            print(f"Received signal: {data}")

            if data == b"0":
                crop_info = {"x": 200, "y": 100, "width": 300, "height": 300}
                cropped_img = crop_img(img, crop_info)
                if cropped_img is not None:
                    result_img, box_count = inference_request(cropped_img, api_url)

                    if result_img is not None:
                        if box_count == 9:
                            print("정상")
                        else:
                            print("비정상")
                        ser.write(b"1")

        if result_img is not None:
            cv2.imshow("Inference Result", result_img)

        if key == 27:  # ESC 키로 종료
            break
        elif key == ord('q'):
            result_img = None

finally:
    # 프로그램 종료 시 카메라와 창 해제
    release_camera()
    cv2.destroyAllWindows()
